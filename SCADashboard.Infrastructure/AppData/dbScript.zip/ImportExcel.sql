-- Bulk insert from Excel
--SELECT *
--INTO TempExcelData
--FROM OPENROWSET('Microsoft.ACE.OLEDB.12.0',
--    'Excel 12.0;Database=C:\Kunde.xlsx;HDR=NO',
--    'SELECT * FROM [Sheet1$]');



--INSERT INTO dbo.Kunde(KundeNo,KundeName)
--SELECT F1, F2 FROM TempExcelData;