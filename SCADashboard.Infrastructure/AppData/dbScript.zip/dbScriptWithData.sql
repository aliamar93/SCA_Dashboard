USE [master]
GO
/****** Object:  Database [SCADASHBOARD]    Script Date: 11/10/2025 8:12:02 AM ******/
CREATE DATABASE [SCADASHBOARD]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'SCADASHBOARD', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\SCADASHBOARD.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'SCADASHBOARD_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS\MSSQL\DATA\SCADASHBOARD_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT
GO
ALTER DATABASE [SCADASHBOARD] SET COMPATIBILITY_LEVEL = 150
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [SCADASHBOARD].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [SCADASHBOARD] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET ARITHABORT OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET AUTO_CLOSE OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [SCADASHBOARD] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [SCADASHBOARD] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET  DISABLE_BROKER 
GO
ALTER DATABASE [SCADASHBOARD] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [SCADASHBOARD] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [SCADASHBOARD] SET  MULTI_USER 
GO
ALTER DATABASE [SCADASHBOARD] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [SCADASHBOARD] SET DB_CHAINING OFF 
GO
ALTER DATABASE [SCADASHBOARD] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [SCADASHBOARD] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [SCADASHBOARD] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [SCADASHBOARD] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [SCADASHBOARD] SET QUERY_STORE = OFF
GO
USE [SCADASHBOARD]
GO
/****** Object:  Table [dbo].[AuditLogs]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditLogs](
	[AuditId] [int] IDENTITY(1,1) NOT NULL,
	[TenantId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[PageId] [int] NULL,
	[Action] [varchar](255) NULL,
	[Timestamp] [datetime] NULL,
	[IPAddress] [varchar](45) NULL,
PRIMARY KEY CLUSTERED 
(
	[AuditId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Kunde]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Kunde](
	[KundeId] [int] IDENTITY(1,1) NOT NULL,
	[KundeNo] [nvarchar](200) NOT NULL,
	[KundeName] [nvarchar](max) NOT NULL,
 CONSTRAINT [PK_Kunde] PRIMARY KEY CLUSTERED 
(
	[KundeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Modules]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Modules](
	[ModuleId] [int] IDENTITY(1,1) NOT NULL,
	[TenantId] [int] NULL,
	[ModuleName] [varchar](100) NOT NULL,
	[Icon] [varchar](50) NULL,
	[OrderIndex] [int] NULL,
	[IsActive] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ModuleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Pages]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Pages](
	[PageId] [int] IDENTITY(1,1) NOT NULL,
	[ModuleId] [int] NOT NULL,
	[TenantId] [int] NULL,
	[PageName] [varchar](150) NOT NULL,
	[PageUrl] [varchar](255) NULL,
	[ComponentName] [varchar](150) NULL,
	[OrderIndex] [int] NULL,
	[IsActive] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Permissions]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Permissions](
	[PermissionId] [int] IDENTITY(1,1) NOT NULL,
	[PermissionName] [varchar](50) NOT NULL,
	[Description] [varchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[PermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RolePagePermissions]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RolePagePermissions](
	[RolePagePermissionId] [int] IDENTITY(1,1) NOT NULL,
	[TenantId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
	[PageId] [int] NOT NULL,
	[CanView] [bit] NULL,
	[CanAdd] [bit] NULL,
	[CanEdit] [bit] NULL,
	[CanDelete] [bit] NULL,
PRIMARY KEY CLUSTERED 
(
	[RolePagePermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Roles]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Roles](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[TenantId] [int] NOT NULL,
	[RoleName] [varchar](100) NOT NULL,
	[Description] [varchar](255) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Tenants]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Tenants](
	[TenantId] [int] IDENTITY(1,1) NOT NULL,
	[TenantName] [varchar](200) NOT NULL,
	[Domain] [varchar](255) NULL,
	[ContactEmail] [varchar](255) NULL,
	[ContactPhone] [varchar](50) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[TenantId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Userkunde]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Userkunde](
	[UserKundeId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NULL,
	[KundeId] [int] NULL,
 CONSTRAINT [PK_Userkunde] PRIMARY KEY CLUSTERED 
(
	[UserKundeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserRoles]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserRoles](
	[UserRoleId] [int] IDENTITY(1,1) NOT NULL,
	[UserId] [int] NOT NULL,
	[RoleId] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[UserRoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 11/10/2025 8:12:03 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[TenantId] [int] NOT NULL,
	[Username] [varchar](100) NOT NULL,
	[Email] [varchar](255) NOT NULL,
	[PasswordHash] [varchar](255) NOT NULL,
	[FullName] [varchar](200) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedDate] [datetime] NULL,
	[UpdatedDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
SET IDENTITY_INSERT [dbo].[Modules] ON 
GO
INSERT [dbo].[Modules] ([ModuleId], [TenantId], [ModuleName], [Icon], [OrderIndex], [IsActive]) VALUES (1, 1, N'Dashboard', N'icon ni ni-presentation', 1, 1)
GO
INSERT [dbo].[Modules] ([ModuleId], [TenantId], [ModuleName], [Icon], [OrderIndex], [IsActive]) VALUES (2, 1, N'User Management', N'icon ni ni-users', 2, 1)
GO
SET IDENTITY_INSERT [dbo].[Modules] OFF
GO
SET IDENTITY_INSERT [dbo].[Pages] ON 
GO
INSERT [dbo].[Pages] ([PageId], [ModuleId], [TenantId], [PageName], [PageUrl], [ComponentName], [OrderIndex], [IsActive]) VALUES (1, 1, 1, N'Dashboard', N'/Dashboard', N'DashboardPage', 1, 1)
GO
INSERT [dbo].[Pages] ([PageId], [ModuleId], [TenantId], [PageName], [PageUrl], [ComponentName], [OrderIndex], [IsActive]) VALUES (2, 2, 1, N'User', N'/user', N'UserListPage', 1, 1)
GO
INSERT [dbo].[Pages] ([PageId], [ModuleId], [TenantId], [PageName], [PageUrl], [ComponentName], [OrderIndex], [IsActive]) VALUES (3, 2, 1, N'Roles & Permissions', N'/role', N'RolesPage', 2, 1)
GO
SET IDENTITY_INSERT [dbo].[Pages] OFF
GO
SET IDENTITY_INSERT [dbo].[RolePagePermissions] ON 
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (1, 1, 1, 1, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (2, 1, 1, 2, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (3, 1, 1, 3, 0, 0, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (4, 2, 2, 1, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (5, 2, 2, 2, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (6, 2, 2, 3, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (10, 1, 5, 1, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (11, 1, 5, 2, 1, 1, 1, 1)
GO
INSERT [dbo].[RolePagePermissions] ([RolePagePermissionId], [TenantId], [RoleId], [PageId], [CanView], [CanAdd], [CanEdit], [CanDelete]) VALUES (12, 1, 5, 3, 0, 0, 0, 0)
GO
SET IDENTITY_INSERT [dbo].[RolePagePermissions] OFF
GO
SET IDENTITY_INSERT [dbo].[Roles] ON 
GO
INSERT [dbo].[Roles] ([RoleId], [TenantId], [RoleName], [Description], [IsActive], [CreatedDate]) VALUES (1, 1, N'Admin', N'Full access for Alpha Corp', 1, CAST(N'2025-10-28T09:38:54.303' AS DateTime))
GO
INSERT [dbo].[Roles] ([RoleId], [TenantId], [RoleName], [Description], [IsActive], [CreatedDate]) VALUES (2, 2, N'Manager', N'Full access for Beta Ltd', 1, CAST(N'2025-10-28T09:38:54.303' AS DateTime))
GO
INSERT [dbo].[Roles] ([RoleId], [TenantId], [RoleName], [Description], [IsActive], [CreatedDate]) VALUES (5, 1, N'Ahead', N'Kunde', 1, CAST(N'2025-11-05T07:39:58.147' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Roles] OFF
GO
SET IDENTITY_INSERT [dbo].[Tenants] ON 
GO
INSERT [dbo].[Tenants] ([TenantId], [TenantName], [Domain], [ContactEmail], [ContactPhone], [IsActive], [CreatedDate]) VALUES (1, N'Alpha Corp', N'alpha.example.com', N'admin@alpha.com', NULL, 1, CAST(N'2025-10-28T09:38:54.290' AS DateTime))
GO
INSERT [dbo].[Tenants] ([TenantId], [TenantName], [Domain], [ContactEmail], [ContactPhone], [IsActive], [CreatedDate]) VALUES (2, N'Beta Ltd', N'beta.example.com', N'admin@beta.com', NULL, 1, CAST(N'2025-10-28T09:38:54.290' AS DateTime))
GO
SET IDENTITY_INSERT [dbo].[Tenants] OFF
GO
SET IDENTITY_INSERT [dbo].[UserRoles] ON 
GO
INSERT [dbo].[UserRoles] ([UserRoleId], [UserId], [RoleId]) VALUES (1, 1, 1)
GO
INSERT [dbo].[UserRoles] ([UserRoleId], [UserId], [RoleId]) VALUES (2, 2, 2)
GO
INSERT [dbo].[UserRoles] ([UserRoleId], [UserId], [RoleId]) VALUES (15, 21, 2)
GO
INSERT [dbo].[UserRoles] ([UserRoleId], [UserId], [RoleId]) VALUES (16, 24, 1)
GO
INSERT [dbo].[UserRoles] ([UserRoleId], [UserId], [RoleId]) VALUES (17, 25, 1)
GO
INSERT [dbo].[UserRoles] ([UserRoleId], [UserId], [RoleId]) VALUES (18, 26, 2)
GO
SET IDENTITY_INSERT [dbo].[UserRoles] OFF
GO
SET IDENTITY_INSERT [dbo].[Users] ON 
GO
INSERT [dbo].[Users] ([UserId], [TenantId], [Username], [Email], [PasswordHash], [FullName], [IsActive], [CreatedDate], [UpdatedDate]) VALUES (1, 1, N'Ather', N'admin@alpha.com', N'sca123', N'Alpha Administrator', 1, CAST(N'2025-10-28T09:38:54.310' AS DateTime), NULL)
GO
INSERT [dbo].[Users] ([UserId], [TenantId], [Username], [Email], [PasswordHash], [FullName], [IsActive], [CreatedDate], [UpdatedDate]) VALUES (2, 1, N'Amar', N'test@test.com', N'$2a$12$A6tEJV/ucSewtYz602neoeznsCf63DoYv6Y4bJoVjAOTyYZqAmD7i', N'Beta Administrator', 1, CAST(N'2025-10-28T09:38:54.310' AS DateTime), CAST(N'2025-11-05T09:04:49.243' AS DateTime))
GO
INSERT [dbo].[Users] ([UserId], [TenantId], [Username], [Email], [PasswordHash], [FullName], [IsActive], [CreatedDate], [UpdatedDate]) VALUES (21, 1, N'aliamar', N'test1@test.com', N'$2a$12$ATIvJUfX/FBXvpCe6uNIl.H.n.PGmxdkbeUTB2bf2/M.8nntc8rv6', N'Amar Ali', 1, CAST(N'2025-11-05T12:16:49.133' AS DateTime), CAST(N'2025-11-08T09:03:53.677' AS DateTime))
GO
INSERT [dbo].[Users] ([UserId], [TenantId], [Username], [Email], [PasswordHash], [FullName], [IsActive], [CreatedDate], [UpdatedDate]) VALUES (24, 1, N'Athe', N'sca@sca.com', N'$2a$12$4CcCDtZ5NVNvXqmebMCrye37wvdHSCD13ciQHswljH2sp9KdGmJnG', N'Beta Administrator', 1, CAST(N'2025-11-05T12:21:25.007' AS DateTime), CAST(N'2025-11-05T12:26:38.307' AS DateTime))
GO
INSERT [dbo].[Users] ([UserId], [TenantId], [Username], [Email], [PasswordHash], [FullName], [IsActive], [CreatedDate], [UpdatedDate]) VALUES (25, 1, N'aliamar93', N'test1@test1.com', N'$2a$12$KNOgpTS7m/xjqBASoHkgBO84NiRr1GoDvebpSL/A7Lb/Xfdp1p/VG', N'Amar Ali', 1, CAST(N'2025-11-06T07:45:37.343' AS DateTime), NULL)
GO
INSERT [dbo].[Users] ([UserId], [TenantId], [Username], [Email], [PasswordHash], [FullName], [IsActive], [CreatedDate], [UpdatedDate]) VALUES (26, 1, N'aliamar93s', N'test1@test1s.com', N'$2a$12$Gtq08PR/l1LgMt2J17pU.uBHpYPm6KfP19RTeTc2VOIAG/8n3RlFO', N'Amar Ali', 1, CAST(N'2025-11-06T08:11:48.257' AS DateTime), NULL)
GO
SET IDENTITY_INSERT [dbo].[Users] OFF
GO
/****** Object:  Index [UQ_RolePage_Tenant]    Script Date: 11/10/2025 8:12:03 AM ******/
ALTER TABLE [dbo].[RolePagePermissions] ADD  CONSTRAINT [UQ_RolePage_Tenant] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[RoleId] ASC,
	[PageId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ_Role_Tenant]    Script Date: 11/10/2025 8:12:03 AM ******/
ALTER TABLE [dbo].[Roles] ADD  CONSTRAINT [UQ_Role_Tenant] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[RoleName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [UQ_UserRole]    Script Date: 11/10/2025 8:12:03 AM ******/
ALTER TABLE [dbo].[UserRoles] ADD  CONSTRAINT [UQ_UserRole] UNIQUE NONCLUSTERED 
(
	[UserId] ASC,
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UQ_User_Tenant]    Script Date: 11/10/2025 8:12:03 AM ******/
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [UQ_User_Tenant] UNIQUE NONCLUSTERED 
(
	[TenantId] ASC,
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AuditLogs] ADD  DEFAULT (getdate()) FOR [Timestamp]
GO
ALTER TABLE [dbo].[Modules] ADD  DEFAULT ((0)) FOR [OrderIndex]
GO
ALTER TABLE [dbo].[Modules] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Pages] ADD  DEFAULT ((0)) FOR [OrderIndex]
GO
ALTER TABLE [dbo].[Pages] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[RolePagePermissions] ADD  DEFAULT ((0)) FOR [CanView]
GO
ALTER TABLE [dbo].[RolePagePermissions] ADD  DEFAULT ((0)) FOR [CanAdd]
GO
ALTER TABLE [dbo].[RolePagePermissions] ADD  DEFAULT ((0)) FOR [CanEdit]
GO
ALTER TABLE [dbo].[RolePagePermissions] ADD  DEFAULT ((0)) FOR [CanDelete]
GO
ALTER TABLE [dbo].[Roles] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Roles] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[Tenants] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Tenants] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT (getdate()) FOR [CreatedDate]
GO
ALTER TABLE [dbo].[AuditLogs]  WITH CHECK ADD FOREIGN KEY([PageId])
REFERENCES [dbo].[Pages] ([PageId])
GO
ALTER TABLE [dbo].[AuditLogs]  WITH CHECK ADD FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([TenantId])
GO
ALTER TABLE [dbo].[AuditLogs]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[Modules]  WITH CHECK ADD FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([TenantId])
GO
ALTER TABLE [dbo].[Pages]  WITH CHECK ADD FOREIGN KEY([ModuleId])
REFERENCES [dbo].[Modules] ([ModuleId])
GO
ALTER TABLE [dbo].[Pages]  WITH CHECK ADD FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([TenantId])
GO
ALTER TABLE [dbo].[RolePagePermissions]  WITH CHECK ADD FOREIGN KEY([PageId])
REFERENCES [dbo].[Pages] ([PageId])
GO
ALTER TABLE [dbo].[RolePagePermissions]  WITH CHECK ADD FOREIGN KEY([RoleId])
REFERENCES [dbo].[Roles] ([RoleId])
GO
ALTER TABLE [dbo].[RolePagePermissions]  WITH CHECK ADD FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([TenantId])
GO
ALTER TABLE [dbo].[Roles]  WITH CHECK ADD FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([TenantId])
GO
ALTER TABLE [dbo].[Userkunde]  WITH CHECK ADD  CONSTRAINT [FK_Userkunde_Kunde] FOREIGN KEY([KundeId])
REFERENCES [dbo].[Kunde] ([KundeId])
GO
ALTER TABLE [dbo].[Userkunde] CHECK CONSTRAINT [FK_Userkunde_Kunde]
GO
ALTER TABLE [dbo].[Userkunde]  WITH CHECK ADD  CONSTRAINT [FK_Userkunde_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[Userkunde] CHECK CONSTRAINT [FK_Userkunde_Users]
GO
ALTER TABLE [dbo].[UserRoles]  WITH CHECK ADD FOREIGN KEY([RoleId])
REFERENCES [dbo].[Roles] ([RoleId])
GO
ALTER TABLE [dbo].[UserRoles]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[Users]  WITH CHECK ADD FOREIGN KEY([TenantId])
REFERENCES [dbo].[Tenants] ([TenantId])
GO
USE [master]
GO
ALTER DATABASE [SCADASHBOARD] SET  READ_WRITE 
GO
